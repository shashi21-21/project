package com.PaymentMethod1.shash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentMethod1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
