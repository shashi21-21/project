package com.PaymentMethod1.PaymentMethodRepository;

import org.springframework.data.repository.CrudRepository;

import com.PaymentMethod1.beans.Card;

public interface CardRepository extends CrudRepository<Card, String> {

}
