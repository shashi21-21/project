package com.PaymentMethod1.PaymentMethodRepository;

import org.springframework.data.repository.CrudRepository;

import com.PaymentMethod1.beans.Card_Expiry;

public interface Card_ExpiryRepository extends CrudRepository<Card_Expiry, String> {

}
