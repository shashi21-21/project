package com.PaymentMethod1.PaymentMethodRepository;

import org.springframework.data.repository.CrudRepository;

import com.PaymentMethod1.beans.Billing_Details;

public interface Billing_DetailsRepository  extends CrudRepository<Billing_Details, String>{

}
