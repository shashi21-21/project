package com.PaymentMethod1.PaymentMethodRepository;

import org.springframework.data.repository.CrudRepository;

import com.PaymentMethod1.beans.Return_Links;

public interface Return_LinksReposiory extends CrudRepository<Return_Links, String>
{

}
