package com.PaymentMethod1.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class Payment_Method
{
    @Id
    private String id;
    private int amount;
    private String merchant_Ref_Num;
    private String action;
    private String currency_Code;
    private String usage;
    private String status;
    private int time_To_Live_Seconds;
    private String transaction_Type;
    private String payment_Type;
    private String execution_Mode;
    private String customer_Ip;
    private String  payment_Handle_Token;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getMerchant_Ref_Num() {
		return merchant_Ref_Num;
	}
	public void setMerchant_Ref_Num(String merchant_Ref_Num) {
		this.merchant_Ref_Num = merchant_Ref_Num;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCurrency_Code() {
		return currency_Code;
	}
	public void setCurrency_Code(String currency_Code) {
		this.currency_Code = currency_Code;
	}
	public String getUsage() {
		return usage;
	}
	public void setUsage(String usage) {
		this.usage = usage;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTime_To_Live_Seconds() {
		return time_To_Live_Seconds;
	}
	public void setTime_To_Live_Seconds(int time_To_Live_Seconds) {
		this.time_To_Live_Seconds = time_To_Live_Seconds;
	}
	public String getTransaction_Type() {
		return transaction_Type;
	}
	public void setTransaction_Type(String transaction_Type) {
		this.transaction_Type = transaction_Type;
	}
	public String getPayment_Type() {
		return payment_Type;
	}
	public void setPayment_Type(String payment_Type) {
		this.payment_Type = payment_Type;
	}
	public String getExecution_Mode() {
		return execution_Mode;
	}
	public void setExecution_Mode(String execution_Mode) {
		this.execution_Mode = execution_Mode;
	}
	public String getCustomer_Ip() {
		return customer_Ip;
	}
	public void setCustomer_Ip(String customer_Ip) {
		this.customer_Ip = customer_Ip;
	}
	public String getPayment_Handle_Token() {
		return payment_Handle_Token;
	}
	public void setPayment_Handle_Token(String payment_Handle_Token) {
		this.payment_Handle_Token = payment_Handle_Token;
	}
	@Override
	public String toString() {
		return "Payment_Method [id=" + id + ", amount=" + amount + ", merchant_Ref_Num=" + merchant_Ref_Num
				+ ", action=" + action + ", currency_Code=" + currency_Code + ", usage=" + usage + ", status=" + status
				+ ", time_To_Live_Seconds=" + time_To_Live_Seconds + ", transaction_Type=" + transaction_Type
				+ ", payment_Type=" + payment_Type + ", execution_Mode=" + execution_Mode + ", customer_Ip="
				+ customer_Ip + ", payment_Handle_Token=" + payment_Handle_Token + ", getId()=" + getId()
				+ ", getAmount()=" + getAmount() + ", getMerchant_Ref_Num()=" + getMerchant_Ref_Num() + ", getAction()="
				+ getAction() + ", getCurrency_Code()=" + getCurrency_Code() + ", getUsage()=" + getUsage()
				+ ", getStatus()=" + getStatus() + ", getTime_To_Live_Seconds()=" + getTime_To_Live_Seconds()
				+ ", getTransaction_Type()=" + getTransaction_Type() + ", getPayment_Type()=" + getPayment_Type()
				+ ", getExecution_Mode()=" + getExecution_Mode() + ", getCustomer_Ip()=" + getCustomer_Ip()
				+ ", getPayment_Handle_Token()=" + getPayment_Handle_Token() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}
    

		