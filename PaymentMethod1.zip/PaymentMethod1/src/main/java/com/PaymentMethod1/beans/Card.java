package com.PaymentMethod1.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
public class Card 
{
	@Id
	private String holder_name;
	private String card_type;
	private String card_bin;
	private String  last_digits;
	public String getHolder_name() {
		return holder_name;
	}
	public void setHolder_name(String holder_name) {
		this.holder_name = holder_name;
	}
	public String getCard_type() {
		return card_type;
	}
	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}
	public String getCard_bin() {
		return card_bin;
	}
	public void setCard_bin(String card_bin) {
		this.card_bin = card_bin;
	}
	public String getLast_digits() {
		return last_digits;
	}
	public void setLast_digits(String last_digits) {
		this.last_digits = last_digits;
	}
	@Override
	public String toString() {
		return "Card [holder_name=" + holder_name + ", card_type=" + card_type + ", card_bin=" + card_bin
				+ ", last_digits=" + last_digits + ", getHolder_name()=" + getHolder_name() + ", getCard_type()="
				+ getCard_type() + ", getCard_bin()=" + getCard_bin() + ", getLast_digits()=" + getLast_digits()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	
    
	}