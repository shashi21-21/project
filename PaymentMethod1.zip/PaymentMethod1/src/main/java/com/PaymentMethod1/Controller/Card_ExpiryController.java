package com.PaymentMethod1.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PaymentMethod1.PaymentMethodRepository.Card_ExpiryRepository;
import com.PaymentMethod1.beans.Card_Expiry;
@RestController
@RequestMapping("/card")
public class Card_ExpiryController 
{

	@Autowired
    Card_ExpiryRepository repository;
	
	
	@GetMapping("/readAll")
	public Iterable<Card_Expiry> readAll()
	{
		Iterable<Card_Expiry> card_expiry=repository.findAll();
		
		return    card_expiry;
			}
	
	
}


