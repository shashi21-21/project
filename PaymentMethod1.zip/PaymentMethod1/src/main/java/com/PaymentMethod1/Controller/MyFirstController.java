package com.PaymentMethod1.Controller;



import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PaymentMethod1.PaymentMethodRepository.Billing_DetailsRepository;
import com.PaymentMethod1.PaymentMethodRepository.CardRepository;
import com.PaymentMethod1.PaymentMethodRepository.Card_ExpiryRepository;
import com.PaymentMethod1.PaymentMethodRepository.Payment_MethodRepository;
import com.PaymentMethod1.PaymentMethodRepository.Return_LinksReposiory;
import com.PaymentMethod1.beans.Billing_Details;
import com.PaymentMethod1.beans.Card;
import com.PaymentMethod1.beans.Card_Expiry;
import com.PaymentMethod1.beans.Payment_Method;
import com.PaymentMethod1.beans.Return_Links;
import com.google.gson.Gson;



@RestController
@RequestMapping("/pay")
public class MyFirstController
{
	
	@Autowired
	private Payment_MethodRepository repository;
	
	@Autowired
	private Billing_DetailsRepository billingRepository;
	
	@Autowired
	private CardRepository cardRepository;
	
	@Autowired
	private Card_ExpiryRepository cardExpiryRepository;
	
	@Autowired
	private Return_LinksReposiory  returnLinkRepository;
	
	

	@GetMapping("/readAll")
	public String readAll() {
		Iterable<Payment_Method> all = repository.findAll();
		Gson gson = new Gson();
		String json = gson.toJson(all);

		JSONArray j1 = new JSONArray(json);
		JSONObject res = new JSONObject(j1.get(0).toString());

		Iterable<Billing_Details> billingResponse = billingRepository.findAll();

		json = gson.toJson(billingResponse);
		JSONObject billingJson = new JSONObject(new JSONArray(json).get(0).toString());
		res.put("BillingDetails", billingJson);

		// to get card

		Iterable<Card> cardResponse = cardRepository.findAll();

		json = gson.toJson(cardResponse);
		JSONObject cardJson = new JSONObject(new JSONArray(json).get(0).toString());
		// GET the card expiry
		Iterable<Card_Expiry> cardExpiry = cardExpiryRepository.findAll();

		json = gson.toJson(cardExpiry);
		JSONObject cardExpiryJson = new JSONObject(new JSONArray(json).get(0).toString());
		cardJson.put("caredExpiry", cardExpiryJson);

		res.put("card", cardJson);
		
		
		//returnlink
		
		Iterable<Return_Links>returnLinks = returnLinkRepository.findAll();
		
		   json=gson.toJson(returnLinks);
		  /* JSONObject returnlinksJson = new JSONObject(new JSONArray(json).get(0).toString());*/
			res.put("returnLinks",new JSONArray(json));
		
		
		return res.toString();
	}
}
		
		
		
		
		
	

