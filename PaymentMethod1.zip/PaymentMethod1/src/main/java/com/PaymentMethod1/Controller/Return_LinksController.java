package com.PaymentMethod1.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PaymentMethod1.PaymentMethodRepository.Return_LinksReposiory;
import com.PaymentMethod1.beans.Payment_Method;
import com.PaymentMethod1.beans.Return_Links;

@RestController
@RequestMapping("/link")
public class Return_LinksController 
{  
	  @Autowired
      private Return_LinksReposiory reposiory ;
      
      @GetMapping("/readAll")
  	public Iterable<Return_Links> readAll()
  	{
  		Iterable<Return_Links> e2= reposiory.findAll();
  		
  		return e2;
  			}
  	
}
