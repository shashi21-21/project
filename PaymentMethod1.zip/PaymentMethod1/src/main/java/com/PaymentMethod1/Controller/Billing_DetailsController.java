package com.PaymentMethod1.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.PaymentMethod1.PaymentMethodRepository.Billing_DetailsRepository;

import com.PaymentMethod1.beans.Billing_Details;
import com.PaymentMethod1.beans.Payment_Method;


@RestController
@RequestMapping("/billing")
public class Billing_DetailsController 
{
		@Autowired
	    Billing_DetailsRepository repository;
		
		
		@GetMapping("/readAll")		
		public Iterable<Billing_Details> readAll()
		{
			Iterable<Billing_Details>    billing_Details=repository.findAll();
			
			return     billing_Details;
				}
		
		
	}


